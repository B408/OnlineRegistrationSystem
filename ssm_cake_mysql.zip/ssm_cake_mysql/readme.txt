﻿
数据库脚本: cake.sql
数据库文档: cake.doc


默认访问地址: http://localhost:8080/ssm_cake_mysql/index.jsp
默认访问地址: http://localhost:8080/ssm_cake_mysql/admin.jsp
默认后台用户: 用户名:admin 密码:admin


后端框架: spring4.3 + mybatis3.4
前端框架: jquery + layer